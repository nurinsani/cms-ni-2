<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HistoryApprove extends Model
{
    use HasFactory;

    protected $table = 'history_approve';
    protected $guarded = [];
}
