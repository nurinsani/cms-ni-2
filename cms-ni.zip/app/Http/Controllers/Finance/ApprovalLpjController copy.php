<?php

namespace App\Http\Controllers\Finance;

use App\Http\Controllers\Controller;
use App\Models\Admin\Pengajuan;
use App\Models\Akunting\Transaksi;
use App\Models\Branch;
use App\Models\TransaksiAp;
use App\Models\TransaksiKp;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class ApprovalLpjController extends Controller
{
    public function index()
    {
        $data['title'] = 'Pengajuan LPJ';
        $data['lpj'] = Pengajuan::where('status_approve', 'lpj-finance')->get();
        // $data['lpj'] = Pengajuan::where('status_approve', 'selesai')->get();
        return view('finance.approval.pengajuan-lpj.index', $data);
    }

    public function detail($id)
    {
        $data['title'] = 'Detail LPJ';
        $data['lpj'] = Pengajuan::findOrFail($id);
        return view('finance.approval.pengajuan-lpj.detail', $data);
    }

    public function approve(Request $request, $id)
    {
        $pengajuan = Pengajuan::findOrfail($id);
            $pengajuan->status_approve = 'selesai';
            $pengajuan->save();

            foreach ($pengajuan->pengajuan_details as $key => $cabang) {

            }

            // jurnal LPJ normal
            if ($cabang->harga == $cabang->harga_pembelian) {                
                if ($cabang->kode_branch == NULL) {
                    foreach ($pengajuan->pengajuan_details as $key => $cabang) {
                        $subtotal = 0;
                        $total = $cabang->harga * $cabang->kuantitas;
                        $subtotal = $subtotal + $total;
                    }
                    
                    // Jurnal LPJ Pembelian Peralatan Cabang
                    $branch = Branch::where('code_area', $cabang->kode_area)->get();
                    $total = $branch->count();

                    // jurnal LPJ pembelian untuk cabang di KP
                    foreach ($branch as $key => $data) {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010'.'-'.$data->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.$data->unit,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);
                    }
        
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                    // end jurnal LPJ pembelian untuk cabang di KP

                    
                    // jurnal LPJ   pembelian untuk cabang di AP
                    foreach ($branch as $key => $data) {
                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $cabang->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $cabang->jenis_peralatan->param_peralatan->nama,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);

                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $cabang->harga_pembelian / $total
                        ]);
                    }
                    
                } else {
                    // jurnal di KP
                    foreach ($pengajuan->pengajuan_details as $item) {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }
        
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);

                    // Jurnal Pembelian Untuk AP
                    foreach ($pengajuan->pengajuan_details as $item) {
                        $subtotal = 0;
                        $total = $item->harga * $item->kuantitas;
                        $subtotal = $subtotal + $total;

                        // jurnal di AP
                        TransaksiAp::create([
                            'kode_branch' => $item->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$item->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $cabang->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }

                    TransaksiAp::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                        'kode_rekening' => '2500000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'RAK PASIVA - KP',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                }
                // end jurnal pembelian untuk cabang AP
                // end Jurnal Pembelian Peralatan Cabang
            }
            // end LPJ normal
            
            // jurnal LPJ pengajuan lebih besar dari pengajuan
            if ($cabang->harga < $cabang->harga_pembelian) {
                if ($cabang->kode_branch == NULL) {
                    // Jurnal Pembelian Peralatan Cabang
                    foreach ($pengajuan->pengajuan_details as $key => $cabang) {
                        $subtotal = 0;
                        $total = $cabang->harga * $cabang->kuantitas;
                        $subtotal = $subtotal + $total;
                    }

                    $branch = Branch::where('code_area', $cabang->kode_area)->get();
                    $ap = Branch::where('code_area', $cabang->kode_area)->get();
                    $total = $branch->count();
                    // jurnal pembelian untuk cabang KP
                    foreach ($branch as $key => $data) {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010'.'-'.$data->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.$data->unit,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);
                    }
        
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);

                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1312000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro Bank BSI Ex BNI Syariah - 8080887729 - 8080887730',
                        'debet' => 0,
                        'kredit' => $cabang->harga_pembelian - $pengajuan->subtotal()
                    ]);
                    // end jurnal pembelian untuk cabang KP
                    
                    // jurnal pembelian untuk cabang AP
                    foreach ($branch as $key => $data) {
                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $cabang->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $cabang->jenis_peralatan->param_peralatan->nama,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);

                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $cabang->harga_pembelian / $total
                        ]);
                    }
                    
                } else {
                    foreach ($pengajuan->pengajuan_details as $item) {
                        $subtotal = 0;
                        $total = $item->harga * $item->kuantitas;
                        $subtotal = $subtotal + $total;
                        
                        // jurnal di AP
                        TransaksiAp::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $item->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
        
                        TransaksiAp::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $item->harga_pembelian,
                        ]);
                        
                    }
        
                    foreach ($pengajuan->pengajuan_details as $item) {
                        // jurnal di KP
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
    
                    }
    
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                    
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1312000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro Bank BSI Ex BNI Syariah - 8080887729 - 8080887730',
                        'debet' => 0,
                        'kredit' => $item->harga_pembelian - $pengajuan->subtotal()
                    ]);
                }
            }
            // end jurnal LPJ pengajuan lebih besar dari pengajuan

            // jika nominal lebih kecil dari pengajuan
            if ($cabang->harga > $cabang->harga_pembelian) {
                if ($cabang->kode_branch == NULL) {
                    // Jurnal Pembelian Peralatan Cabang
                    foreach ($pengajuan->pengajuan_details as $key => $cabang) {
                        $subtotal = 0;
                        $total = $cabang->harga * $cabang->kuantitas;
                        $subtotal = $subtotal + $total;
                    }

                    $branch = Branch::where('code_area', $cabang->kode_area)->get();
                    $total = $branch->count();
                    // jurnal pembelian untuk cabang KP
                    foreach ($branch as $key => $data) {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010'.'-'.$data->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.$data->unit,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);
                    }
                    
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1312000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro BSI Ex BSM - 7777733553',
                        'debet' => $pengajuan->nominal_pengembalian,
                        'kredit' => 0
                    ]);

                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                    // end jurnal pembelian untuk cabang KP
                    
                    // jurnal pembelian untuk cabang AP
                    foreach ($branch as $key => $data) {
                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $cabang->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $cabang->jenis_peralatan->param_peralatan->nama,
                            'debet' => $cabang->harga_pembelian / $total,
                            'kredit' => 0
                        ]);

                        TransaksiAp::create([
                            'kode_branch' => $data->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$data->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $cabang->harga_pembelian / $total
                        ]);
                    }
                    
                } else {
                    foreach ($pengajuan->pengajuan_details as $item) {
                        // jurnal di KP
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }
        
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1311000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro BSI Ex BSM - 7777733553',
                        'debet' => $pengajuan->nominal_pengembalian,
                        'kredit' => 0
                    ]);
        
                    TransaksiKp::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                        'kode_rekening' => '1010-1923000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Pembelian Barang',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);

                    foreach ($pengajuan->pengajuan_details as $item) {
                        $subtotal = 0;
                        $total = $item->harga * $item->kuantitas;
                        $subtotal = $subtotal + $total;
                        
                        // jurnal di AP
                        TransaksiAp::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => $item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $item->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
        
                        TransaksiAp::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $item->harga_pembelian,
                        ]);
                        
                    }
                }
            }

        try {
            DB::beginTransaction();
            

            DB::commit();
            return redirect()->back()->with('success', 'Data berhasil Approve');
        } catch (\Throwable $th) {
            DB::rollback();
            Log::error($th->getMessage());
            return redirect()->back()->with('error', 'Data gagal diapprove');
        }

    }

    public function approve_inventaris(Request $request, $id)
    {
        try {
            DB::beginTransaction();
            $pengajuan = Pengajuan::findOrfail($id);
            $pengajuan->status_approve = 'selesai';
            $pengajuan->save();

            if ($pengajuan->nominal_pengembalian == 0) {
                // jurnal LPJ pembelian inventaris di kp
                foreach ($pengajuan->pengajuan_details as $item) {
                    if ($item->kode_branch == '1010') {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $item->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    } else {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }
                }
    
                TransaksiKp::create([
                    'kode_branch' => 1010,
                    'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                    'kode_rekening' => '1010-1929000',
                    'tanggal_transaksi' => Carbon::now(),
                    'jenis_transaksi' => 'Bukti SYSTEM',
                    'keterangan' => 'UM Lainnya',
                    'debet' => 0,
                    'kredit' => $pengajuan->subtotal()
                ]);
                // end jurnal LPJ pembelian inventaris di kp

                if ($item->kode_branch !== '1010') {
                    // jurnal LPJ pembelian inventaris di ap
                    TransaksiAp::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                        'kode_rekening' => '1652000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'ATI-Inventaris-Gol I-Inventaris',
                        'debet' => $pengajuan->subtotal(),
                        'kredit' => 0
                    ]);
    
                    TransaksiAp::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                        'kode_rekening' => '2500000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'RAK PASIVA - KP',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                    // end jurnal LPJ pembelian inventaris di ap
                }

            }
            // end jurnal normal

            // jika pembelian lebih kecil dari pengajuan
            if ($pengajuan->nominal_pengembalian > 0) {
                // jurnal LPJ pembelian peralatan di KP
                foreach ($pengajuan->pengajuan_details as $item) {
                    if ($item->kode_branch == '1010') {
                        Transaksi::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'-'.'1010'.'-'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $item->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    } else {
                        Transaksi::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'-'.$item->ap->kode_branch.'-'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }
                }
    
                if ($item->kode_branch == '1010') {
                    Transaksi::create([
                        'kode_branch' => 1010,
                        'kode_transaksi' => 'BU'.'-'.'1010'.'-'.Str::random(10),
                        'kode_rekening' => '1010-1311000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro BSI Ex BSM - 7777733553',
                        'debet' => $pengajuan->nominal_pengembalian,
                        'kredit' => 0
                    ]);
        
                    Transaksi::create([
                        'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'-'.'1010'.'-'.Str::random(10),
                        'kode_rekening' => '1010-1929000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Lainnya',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                } else {
                    Transaksi::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'-'.$item->ap->kode_branch.'-'.Str::random(10),
                        'kode_rekening' => '1010-1311000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'PPBL-Giro BSI Ex BSM - 7777733553',
                        'debet' => $pengajuan->nominal_pengembalian,
                        'kredit' => 0
                    ]);
        
                    Transaksi::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'-'.$item->ap->kode_branch.'-'.Str::random(10),
                        'kode_rekening' => '1010-1929000',
                        'tanggal_transaksi' => Carbon::now(),
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'UM Lainnya',
                        'debet' => 0,
                        'kredit' => $pengajuan->subtotal()
                    ]);
                } // end LPJ pembelian peralatan di KP

                // jurnal LPJ pembelian peralatan di AP
                foreach ($pengajuan->pengajuan_details as $item) {
                    if ($item->kode_branch != '1010') {
                        Transaksi::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'-'.$item->ap->kode_branch.'-'.Str::random(10),
                            'kode_rekening' => $item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'Pembelian'.' '.$item->jenis_peralatan->nama_jenis.' '.'AP'.' '.$item->ap->unit,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
        
                        Transaksi::create([
                            'kode_branch' => $item->ap->kode_branch,
                            'kode_transaksi' => 'BU'.'-'.$item->ap->kode_branch.'-'.Str::random(10),
                            'kode_rekening' => '2500000',
                            'tanggal_transaksi' => $item->tanggal_pembelian,
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK PASIVA - KP',
                            'debet' => 0,
                            'kredit' => $item->harga_pembelian,
                        ]);
                    }
                } // end jurnal LPJ pembelian peralatan di AP

            }

            // jika pembelian lebih besar dari pengajuan
            if ($pengajuan->nominal_kurang > 0) {
                foreach ($pengajuan->pengajuan_details as $item) {
                    
                    // jurnal LPJ pembelian inventaris di kp
                    if ($item->kode_branch == '1010') {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->jenis_peralatan->param_peralatan->coa,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => $item->jenis_peralatan->param_peralatan->nama,
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    } else {
                        TransaksiKp::create([
                            'kode_branch' => 1010,
                            'kode_transaksi' => 'BU'.'/'.'1010'.'/'.Str::random(10),
                            'kode_rekening' => '1010-'.$item->ap->GL,
                            'tanggal_transaksi' => Carbon::now(),
                            'jenis_transaksi' => 'Bukti SYSTEM',
                            'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                            'debet' => $item->harga_pembelian,
                            'kredit' => 0
                        ]);
                    }
                    
                }
    
                foreach ($pengajuan->pengajuan_details as $item) {
                    // jurnal di KP
                    Transaksi::create([
                        'kode_branch' => $item->ap->kode_branch,
                        'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                        'kode_rekening' => '1010-'.$item->ap->GL,
                        'tanggal_transaksi' => $item->tanggal_pembelian,
                        'jenis_transaksi' => 'Bukti SYSTEM',
                        'keterangan' => 'RAK Aktiva - Unit'.' '.ucfirst($item->ap->unit),
                        'debet' => $item->harga_pembelian,
                        'kredit' => 0
                    ]);
                }
    
                Transaksi::create([
                    'kode_branch' => $item->ap->kode_branch,
                    'kode_transaksi' => 'BU'.'/'.$item->ap->kode_branch.'/'.Str::random(10),
                    'kode_rekening' => '1010-1923000',
                    'tanggal_transaksi' => $item->tanggal_pembelian,
                    'jenis_transaksi' => 'Bukti SYSTEM',
                    'keterangan' => 'UM Pembelian Barang',
                    'debet' => 0,
                    'kredit' => $pengajuan->subtotal()
                ]);
            }

            DB::commit();
            return redirect()->back()->with('success', 'Data berhasil Approve');
        } catch (\Throwable $th) {
            DB::rollback();
            Log::error($th->getMessage());
            return redirect()->back()->with('error', 'Data gagal diapprove');
        }

    }

    public function tolak(Request $request, $id)
    {
        // dd($request->all());
        try {
            DB::beginTransaction();
            $pengajuan = Pengajuan::findOrfail($id);
            $pengajuan->status_approve = 'lpj-akunting-it';
            $pengajuan->save();
            DB::commit();
            return redirect()->back()->with('success', 'Data berhasil Tolak');
        } catch (\Throwable $th) {
            DB::rollback();
            Log::error($th->getMessage());
            return redirect()->back()->with('error', 'Data gagal ditolak');
        }
    }

    public function approve_lpj()
    {
        $data['title'] = 'Pengajuan LPJ';
        $data['lpj'] = Pengajuan::where('status_approve', 'selesai')->get();
        return view('finance.approval.pengajuan-lpj.index', $data);
    }
}
